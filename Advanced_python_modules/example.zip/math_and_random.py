import math
# help(math)
value = 4.35
print(math.floor(value))
print(math.ceil(value))

import random
print(random.randint(0, 100))